# AXI 3단계 — Mode 1 시퀀서 FSM 실물 검증

> **측정일** 2026-09-05 15:45
> **작성** Claude Opus 5 (Claude Code)
> **주의** AI가 생성한 문서입니다. 수치는 사용 전 원본 로그와 대조하십시오.

## 무엇을 확인했나

`CTRL.START` 한 번으로 **RO 켜기 → 주파수 재기 → 안정화 → 누적 → 완료** 가 하드웨어에서
자동으로 도는지 봤다. 소프트웨어는 시작을 걸고 `DONE` 을 기다릴 뿐이다.

FSM 은 `RTL/tdc_seq.v`, 6상태다.

| 상태 | 하는 일 | 나가는 조건 |
|---|---|---|
| `S_IDLE` | 대기 | `START=1` 이고 `HIT_SRC=01` |
| `S_RO_ENABLE` | RO 가동, 초기 트랜지언트 대기 | `SETTLE_N` 클럭 (기본 20,000 = 100 µs) |
| `S_MEAS_FREQ` | RO 주파수 측정 | 온전한 10 ms 게이트 하나 (최대 20 ms) |
| `S_STABILIZE` | 히스토그램 지우기 + 안정화 | `SETTLE_N` 클럭 |
| `S_HISTOGRAM` | 누적 | 목표 히트 도달 또는 `STOP` |
| `S_DONE` | `DONE=1` | `START=0` |

## 빌드

| 항목 | 값 |
|---|---|
| 프로젝트 | `vivado/zed_fsm`, `build_zedboard.tcl -tclargs 1 zed_fsm 1` |
| 전략 | `Performance_ExplorePostRoutePhysOpt` |
| **타이밍** | **WNS +0.221 / WHS +0.037 ns, 위반 0** |
| 체인 | 96단 = 384탭, 맵 버전 4 (`BUILD = 0x01806004`) |

### 첫 빌드는 타이밍이 깨졌다 — 종료 판정이 원인

처음엔 종료 조건을 이렇게 썼다:

```verilog
if (ctrl_stop || ((hit_cnt + (hit_accepted ? 32'd1 : 32'd0)) >= target_hits))
```

32비트 덧셈 → 32비트 비교 → 그 결과가 여러 레지스터의 CE 를 구동한다.
Vivado 실측 : **논리 12단(CARRY4 8개), 데이터 지연 5.900 ns > 예산 5 ns,
slack −1.161 ns, 위반 60곳.** 경로는 `u_seq/histo_en_reg → u_seq/ro_at_end_reg[22]/CE`.

**고친 방식 — 감소 카운터 + 미리 등록한 1비트 플래그:**

```verilog
remain      <= target_hits;              // 시작할 때 장전
remain_last <= (remain == 32'd2);        // '다음이 마지막' 을 미리 계산
if (ctrl_stop || (!unlimited && remain_last && hit_accepted))  // 1비트 둘만 본다
```

뺄셈이 자기 자신으로만 돌아가는 `FF → 가산기 → FF` 경로가 되어 CE 를 몰지 않는다.

홀드 위반 1곳(`u_regs/tgl_d1 → tgl_d2`, CDC 2FF 동기화기, 스큐 0.264 > 데이터 0.220 ns)도
setup 을 고치자 함께 사라졌다. setup 이 60곳 깨진 상태에서 배치기가 그쪽에 매달린 결과였다.

**덤** : `TARGET_HITS = 0` 이 "무제한, `STOP` 으로만 종료" 가 되었다. Mode 2 실측처럼
몇 발이 올지 모를 때 쓴다.

## 결과 — 6항목 전부 통과 (`stage3_check.log`)

```
BUILD    = 0x01806004
S_IDLE 에서 RO_CNT = 0
START -> S_MEAS_FREQ(0ms) -> S_HISTOGRAM(14ms) -> S_DONE(1917ms)
HIT_CNT = 2,000,000   384탭 합 = 2,000,000   차이 0
히트 있는 탭 = 2 ~ 321
DROP_CNT = 0
RO   시작 168,194 -> 끝 168,200
온도 시작 48.59 -> 끝 48.63 C
START 해제 -> S_IDLE 복귀
```

### 1) 핵심 판정 : `HIT_CNT == 384탭 합`, 차이 0

`tdc_histogram` 은 히트 하나에 4클럭을 쓴다 (`IDLE → RMW_R → RMW_A → RMW_W`).
`ts_valid` 를 보는 것은 `IDLE` 한 사이클뿐이라 나머지 3클럭에 온 히트는 버려진다.
따라서 **도착한 히트를 세면 BRAM 에 들어간 수보다 많아진다.**
탭 폭이 `w[i] = h[i]/H × 5000 ps` 이므로 `H` 가 틀리면 모든 탭 폭이 통째로 틀어지고
폭의 합이 5000 ps 가 아니게 된다.

그래서 `HIT_CNT` 는 히스토그램이 "받아들였다"고 알린 것(`hit_accepted`)만 센다.
목표 200만 발 → `HIT_CNT` 200만, PS 가 읽은 384칸의 합도 정확히 200만.
**이제 `H` 를 하드웨어가 보고한 값으로 믿을 수 있다.**

### 2) RO 가 처음으로 꺼졌다

`S_IDLE` 에서 `RO_CNT = 0`. 종전 RTL 은 `ro_enable_reg <= clk_locked` 라 MMCM 이 잠기는
순간부터 영영 발진했고, **껐다 켠 적이 한 번도 없었다.** 이제 FSM 이 잡는다
(`ro_enable_reg <= clk_locked & seq_ro_en`).

### 3) 데드타임 손실 0.00 % — 사전 추정(약 2.4 %)이 틀렸다

`DROP_CNT = 0`. 200만 발 중 한 발도 버려지지 않았다.

추정이 틀린 이유는 히트를 포아송(무작위 도착)으로 가정했기 때문이다. 실제
`hit_random = ro_divider_cnt[5]` 는 링오실레이터를 64분주한 **준주기 신호**라 간격이
거의 일정하다. 67.28 MHz / 64 = 1.051 MHz → 간격 951 ns = 190클럭(@200 MHz).
데드타임 4클럭과 겹칠 일이 사실상 없다.

**그래도 이 카운터는 계속 필요하다.** Mode 2(외부 LVDS 실측)에서는 히트가 진짜
무작위로 오므로 손실이 생긴다. 그때 이 값이 실제 정보가 된다.

### 4) 관측된 상태는 `S_MEAS_FREQ → S_HISTOGRAM → S_DONE` 셋뿐

`S_RO_ENABLE`(100 µs)과 `S_STABILIZE`(100 µs)는 JTAG 폴링(왕복 수 ms)이 못 잡았다.
**누락이 아니라 관측 한계다** — `S_MEAS_FREQ` 가 14 ms 에 끝난 것 자체가 그 앞 상태들을
지나왔다는 증거다.

### 5) 측정 조건이 거의 안 움직였다

1.9 초짜리 측정이라 RO 카운트 차이 6 (0.004 %), 온도 차이 0.05 °C.
긴 측정에서는 이 두 쌍이 의미를 가진다. 200만 발에 1.9 초이므로,
2026-09-04 수준인 4.2억 발이면 약 **6.7 분**이다.

## 부수 확인 — RO 주파수 환산식

```
f_RO = RO_CNT × 4 / 게이트(10 ms)          히트율 = f_RO / 64
```

`ro_divider_cnt` 는 RO 상승엣지마다 +1, 측정 탭이 `[1]` 이라 4번 증가마다 한 주기,
`ro_edge` 는 상승엣지만 세므로 RO 4주기당 1카운트다.

| 측정 | RO_CNT | f_RO | 예상 히트율 | 실측 히트율 |
|---|---|---|---|---|
| 2026-09-04 | 138,716 | 55.49 MHz | 0.867 MHz | 0.867 MHz (문서값) |
| 2026-09-05 2단계 | 196,072 | 78.43 MHz | 1.226 MHz | 1.229 MHz (614만발/5초) |
| 2026-09-05 3단계 | 168,194 | 67.28 MHz | 1.051 MHz | 1.05 MHz (200만발/1.9초) |

세 건 모두 맞는다. 이 확인 과정에서 **`Data/20260904_zed_mode1/README.md` 의
"링오실레이터 111.0 MHz" 가 2배 틀린 값**임을 발견해 정정했다(그 문서의 히트율
0.867 MHz 와 서로 모순이었다). 환산식이 코드 어디에도 없어서 생긴 일이라,
`tdc_axi_regs.v` 의 `A_ROCNT` 주석에 식을 박아 두었다.

> RO 주파수가 빌드마다 다른 것(55.5 → 78.4 → 67.3 MHz)은 재배치로 링 경로가
> 달라진 결과로 **보인다** — 넷리스트를 확인하지 않은 가설이다.
> 코드밀도 교정에는 링 주파수가 들어가지 않으므로(히트가 무작위이기만 하면 됨)
> 측정 결과에는 무관하다.

## 아직 안 된 것

- **Mode 0(DPS)과 Mode 2(EXT)는 FSM 이 받지 않는다.** `S_IDLE` 이 `HIT_SRC=01` 만 본다.
- 개별 히트 타임스탬프를 모으는 캡처 버퍼가 없다. ILA 를 걷어내면서 함께 사라졌고
  아직 되살리지 않았다.
- 런타임 모드 전환에는 클럭 구조 변경(TDC 클럭 고정 + 히트 쪽을 흔들기)이 필요하다.
  Mode 0 의 참 시간축을 건드리는 변경이라 별도 검증이 필요하다.

## 파일

| 파일 | 내용 |
|---|---|
| `stage3_check.log` | 검증 로그 전문 (`tcl/xsct_stage3_check.tcl` 출력) |
| `histo_fsm.csv` | FSM 이 모은 384탭 `Tap_Index,Hit_Count` (총 200만 발) |
| `timing_summary.rpt` / `utilization.rpt` | 이 빌드의 타이밍·자원 |

재현 : `"C:/Xilinx/Vitis/2024.1/bin/xsct.bat" tcl/xsct_stage3_check.tcl`
